
L'archivio contiene quattro cartelle una per ogni pcb.

ogni cartella contiene:

	- .gtl front copper layer
	- .gbl back copper layer

	- .gtp front solder past layer
	- .gbp back solder past layer  

	- .gto front silkscreen layer
	- .gbo back silkscreen layer

	- .gts front soldermask layer
	- .gbs back soldermask layer

	- .pos front components position 
	- .pos back components position

	- .drl file drils
	- .csv bom file


